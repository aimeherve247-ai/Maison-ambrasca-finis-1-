// Données des produits
const products = [
  {
    id: 1,
    name: "J'ADORE EDP",
    price: 86,
    image: "https://i.ibb.co/xqQdFVch/IMG-3773.jpg",
    category: "feminin",
    description: "Parfum floral féminin emblématique",
    capacity: "100ml",
    promo: true,
    originalPrice: 107
  },
  {
    id: 2,
    name: "SAUVAGE EDP",
    price: 100,
    image: "https://i.ibb.co/Q3fSPTYJ/Sauvage-EDP.jpg",
    category: "masculin",
    description: "Fraîcheur audacieuse et sauvage",
    capacity: "100ml"
  },
  {
    id: 3,
    name: "SAUVAGE EAU FORTE",
    price: 130,
    image: "https://i.ibb.co/vCwJVStR/Dior-SAUVAGE-EAU-FORTE.jpg",
    category: "masculin",
    description: "Nouvelle intensité aromatique",
    capacity: "100ml",
    promo: true
  },
  {
    id: 4,
    name: "SAUVAGE ELIXIR",
    price: 120,
    image: "https://i.ibb.co/sdtCG2fF/sauvage-ELIXIR.jpg",
    category: "masculin",
    description: "L'intensité suprême",
    capacity: "100ml"
  },
  {
    id: 5,
    name: "DIOR HOMME INTENSE",
    price: 150,
    image: "https://i.ibb.co/6c69RRCf/Homme-intense.jpg",
    category: "masculin",
    description: "Élégance masculine irisée",
    capacity: "100ml"
  },
  {
    id: 6,
    name: "BOIS D'ARGENT",
    price: 200,
    image: "https://i.ibb.co/RtTDKGh/Bois-d-argent.jpg",
    category: "unisexe",
    description: "Noblesse boisée et irisée",
    capacity: "100ml"
  },
  {
    id: 7,
    name: "PURPLE OUD",
    price: 120.96,
    image: "https://i.ibb.co/NHyr0pC/PURPLE-OUD.jpg",
    category: "unisexe",
    description: "Oud précieux et envoûtant",
    capacity: "100ml"
  },
  {
    id: 8,
    name: "TOBACOLOR",
    price: 150.76,
    image: "https://i.ibb.co/pjq6Jcnr/TABACOLOR.jpg",
    category: "masculin",
    description: "Tabac noble et épicé",
    capacity: "80ml"
  },
  {
    id: 9,
    name: "BLACK OPIUM (YSL)",
    price: 90.95,
    image: "https://i.ibb.co/j2Fry0D/BLACK-OPIUM.jpg",
    category: "feminin",
    description: "Parfum addictif et envoûtant",
    capacity: "100ml"
  },
  {
    id: 10,
    name: "LIBRE EDP",
    price: 110.85,
    image: "https://i.ibb.co/JjtvG4h6/YSL-LIBRE.jpg",
    category: "feminin",
    description: "Élégance libre et affirmée",
    capacity: "100ml"
  },
  {
    id: 12,
    name: "MYSLF PARFUM",
    price: 88.76,
    image: "https://i.ibb.co/xqmvCxQh/YSL-MYSLF.jpg",
    category: "masculin",
    description: "Signature personnelle et unique",
    capacity: "100ml"
  },
  {
    id: 13,
    name: "BOIS PACIFIQUE (Tom Ford)",
    price: 176.88,
    image: "https://i.ibb.co/5x4w16Bh/TOM-FORD-BOIS-PACIFIQUE.jpg",
    category: "masculin",
    description: "Bois marin et minéral",
    capacity: "100ml"
  },
  {
    id: 16,
    name: "BAKARAT 540 (Maison Francis Kurkdjian)",
    price: 90.777,
    image: "https://i.ibb.co/hJtK2pZM/IMG-3786.jpg",
    category: "unisexe",
    description: "Cristal et noblesse olfactive",
    capacity: "200ml",
    promo: true
  },
  {
    id: 17,
    name: "XERJOFF",
    price: 166.55,
    image: "https://i.ibb.co/PsmHQqNM/XERJOFF-NAXOS.jpg",
    category: "unisexe",
    description: "Luxe italien et rareté",
    capacity: "100ml"
  },
  {
    id: 18,
    name: "LE MÂLE ELIXIR (Jean Paul Gaultier)",
    price: 170.88,
    image: "https://i.ibb.co/27MFHDzv/IMG-3788.jpg",
    category: "masculin",
    description: "Icone masculine réinventée",
    capacity: "100ml"
  }
];

// Gestion du panier
class CartManager {
  constructor() {
    this.cart = JSON.parse(localStorage.getItem("ambrosca-cart")) || [];
    this.updateCartUI();
  }

  addToCart(product, price, image) {
    const existingItem = this.cart.find((item) => item.product === product);

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      this.cart.push({
        product,
        price: parseFloat(price),
        image,
        quantity: 1
      });
    }

    this.saveCart();
    this.updateCartUI();
    this.showAddToCartAnimation(product);
  }

  removeFromCart(product) {
    this.cart = this.cart.filter((item) => item.product !== product);
    this.saveCart();
    this.updateCartUI();
  }

  updateQuantity(product, change) {
    const item = this.cart.find((item) => item.product === product);
    if (item) {
      item.quantity += change;
      if (item.quantity <= 0) {
        this.removeFromCart(product);
      } else {
        this.saveCart();
        this.updateCartUI();
      }
    }
  }

  getTotal() {
    return this.cart.reduce(
      (total, item) => total + item.price * item.quantity,
      0
    );
  }

  getTotalItems() {
    return this.cart.reduce((total, item) => total + item.quantity, 0);
  }

  saveCart() {
    localStorage.setItem("ambrosca-cart", JSON.stringify(this.cart));
  }

  updateCartUI() {
    const cartBadge = document.getElementById("cartBadge");
    const cartItems = document.getElementById("cartItems");
    const cartTotal = document.getElementById("cartTotal");

    if (cartBadge) {
      cartBadge.textContent = this.getTotalItems();
    }

    if (cartItems) {
      if (this.cart.length === 0) {
        cartItems.innerHTML =
          '<div class="cart-empty">Votre panier est vide</div>';
      } else {
        cartItems.innerHTML = this.cart
          .map(
            (item) => `
                    <div class="cart-item">
                        <img src="${item.image}" alt="${item.product}" class="cart-item-image"
                             onerror="this.style.display='none'">
                        <div class="cart-item-details">
                            <div class="cart-item-name">${item.product}</div>
                            <div class="cart-item-price">${item.price}$</div>
                            <div class="cart-item-quantity">
                                <button class="quantity-btn" onclick="cartManager.updateQuantity('${item.product}', -1)">-</button>
                                <span>${item.quantity}</span>
                                <button class="quantity-btn" onclick="cartManager.updateQuantity('${item.product}', 1)">+</button>
                            </div>
                        </div>
                    </div>
                `
          )
          .join("");
      }
    }

    if (cartTotal) {
      cartTotal.textContent = `${this.getTotal().toFixed(2)}$`;
    }
  }

  showAddToCartAnimation(product) {
    const button = event.target;
    const originalText = button.innerHTML;

    button.innerHTML = '<i class="fas fa-check"></i> AJOUTÉ';
    button.style.background = "#10B981";
    button.style.borderColor = "#10B981";
    button.style.color = "white";
    button.disabled = true;

    setTimeout(() => {
      button.innerHTML = originalText;
      button.style.background = "";
      button.style.borderColor = "";
      button.style.color = "";
      button.disabled = false;
    }, 2000);
  }

  generateWhatsAppMessage() {
    let message = "Bonjour, je souhaite commander les produits suivants :\n\n";

    this.cart.forEach((item) => {
      message += `• ${item.product} - ${item.quantity}x - ${item.price}$\n`;
    });

    message += `\nTotal: ${this.getTotal().toFixed(2)}$`;
    message += `\n\nNom: [À compléter]`;
    message += `\nAdresse: [À compléter]`;
    message += `\nTéléphone: [À compléter]`;

    return encodeURIComponent(message);
  }
}

// Gestion du carrousel
function initCarousel() {
  const track = document.getElementById("carouselTrack");
  const slides = track.querySelectorAll(".carousel-slide");
  const nav = document.getElementById("carouselNav");

  if (!track || !nav) return;

  let currentSlide = 0;
  const totalSlides = slides.length;

  // Créer les points de navigation
  slides.forEach((_, index) => {
    const dot = document.createElement("div");
    dot.className = `carousel-dot ${index === 0 ? "active" : ""}`;
    dot.addEventListener("click", () => goToSlide(index));
    nav.appendChild(dot);
  });

  function goToSlide(index) {
    currentSlide = index;
    track.style.transform = `translateX(-${currentSlide * 100}%)`;

    nav.querySelectorAll(".carousel-dot").forEach((dot, i) => {
      dot.classList.toggle("active", i === currentSlide);
    });
  }

  function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides;
    goToSlide(currentSlide);
  }

  // Défilement automatique
  let interval = setInterval(nextSlide, 5000);

  // Arrêter le défilement au survol
  track.addEventListener("mouseenter", () => clearInterval(interval));
  track.addEventListener("mouseleave", () => {
    interval = setInterval(nextSlide, 5000);
  });
}

// Rendu des produits
function renderProducts() {
  const grid = document.getElementById("productsGrid");
  if (!grid) return;

  grid.innerHTML = products
    .map(
      (product) => `
        <div class="product-card fade-in">
            ${product.promo ? '<div class="promo-badge">EXCLUSIF</div>' : ""}
            <img src="${product.image}" 
                 alt="${product.name}" class="product-image"
                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
            <div class="image-fallback" style="display: none;">${
              product.name
            }</div>
            <h3 class="product-name">${product.name}</h3>
            <p class="product-description">${product.description}</p>
            <div class="product-capacity">${product.capacity}</div>
            <div class="product-price">
                ${
                  product.originalPrice
                    ? `<span class="product-original-price">${product.originalPrice}$</span>`
                    : ""
                }
                ${
                  typeof product.price === "number"
                    ? product.price.toFixed(2)
                    : product.price
                }$
            </div>
            <button class="btn-add-cart" 
                    data-product="${product.name}" 
                    data-price="${product.price}" 
                    data-image="${product.image}">
                AJOUTER AU PANIER
            </button>
        </div>
    `
    )
    .join("");

  // Re-lier les événements après le rendu
  bindAddToCartEvents();
}

// Gestion de l'administration
class AdminManager {
  constructor() {
    this.isAdmin = localStorage.getItem("ambrosca-admin") === "true";
    this.init();
  }

  init() {
    if (this.isAdmin) {
      this.showAdminFeatures();
    }

    this.bindAdminEvents();
  }

  showAdminFeatures() {
    const adminBanner = document.getElementById("adminBanner");
    const adminToggle = document.getElementById("adminToggle");

    if (adminBanner) adminBanner.classList.remove("hidden");
    if (adminToggle) adminToggle.style.display = "block";
  }

  toggleAdminPanel() {
    const adminPanel = document.getElementById("adminPanel");
    if (adminPanel) {
      adminPanel.classList.toggle("show");
    }
  }

  addProduct(name, price, image) {
    const newProduct = {
      id: products.length + 1,
      name,
      price: parseFloat(price),
      image,
      category: "unisexe",
      description: "Nouveau parfum ajouté",
      capacity: "100ml"
    };

    products.push(newProduct);
    renderProducts();

    // Sauvegarder dans le localStorage
    this.saveProducts();
  }

  updateAdBanner(text) {
    const adminBanner = document.getElementById("adminBanner");
    if (adminBanner) {
      adminBanner.innerHTML = `Mode Administrateur Activé - ${text} - <a href="#" style="color: white; text-decoration: underline;" id="manageAds">Gérer les Publicités</a>`;
    }
  }

  saveProducts() {
    localStorage.setItem("ambrosca-products", JSON.stringify(products));
  }

  loadProducts() {
    const savedProducts = localStorage.getItem("ambrosca-products");
    if (savedProducts) {
      products.push(...JSON.parse(savedProducts));
    }
  }

  bindAdminEvents() {
    const adminToggle = document.getElementById("adminToggle");
    const addPerfumeBtn = document.getElementById("addPerfumeBtn");
    const updateAdBtn = document.getElementById("updateAdBtn");

    if (adminToggle) {
      adminToggle.addEventListener("click", () => this.toggleAdminPanel());
    }

    if (addPerfumeBtn) {
      addPerfumeBtn.addEventListener("click", () => {
        const name = document.getElementById("newPerfumeName").value;
        const price = document.getElementById("newPerfumePrice").value;
        const image = document.getElementById("newPerfumeImage").value;

        if (name && price && image) {
          this.addProduct(name, price, image);
          alert("Parfum ajouté avec succès !");
          document.getElementById("newPerfumeName").value = "";
          document.getElementById("newPerfumePrice").value = "";
          document.getElementById("newPerfumeImage").value = "";
        } else {
          alert("Veuillez remplir tous les champs");
        }
      });
    }

    if (updateAdBtn) {
      updateAdBtn.addEventListener("click", () => {
        const text = document.getElementById("adBannerText").value;
        if (text) {
          this.updateAdBanner(text);
          alert("Bannière publicitaire mise à jour !");
        } else {
          alert("Veuillez entrer un texte pour la bannière");
        }
      });
    }
  }
}

// Gestion du popup WhatsApp
class PopupManager {
  constructor() {
    this.popupShown = localStorage.getItem("ambrosca-popup-shown") === "true";
    this.init();
  }

  init() {
    if (!this.popupShown) {
      setTimeout(() => this.showPopup(), 10000); // Afficher après 10 secondes
    }

    this.bindPopupEvents();
  }

  showPopup() {
    const popup = document.getElementById("whatsappPopup");
    if (popup) {
      popup.classList.add("show");
      localStorage.setItem("ambrosca-popup-shown", "true");
    }
  }

  hidePopup() {
    const popup = document.getElementById("whatsappPopup");
    if (popup) {
      popup.classList.remove("show");
    }
  }

  bindPopupEvents() {
    const closePopup = document.getElementById("closePopup");
    const continueBtn = document.getElementById("continueBtn");
    const whatsappBtn = document.getElementById("whatsappBtn");

    if (closePopup) {
      closePopup.addEventListener("click", () => this.hidePopup());
    }

    if (continueBtn) {
      continueBtn.addEventListener("click", () => this.hidePopup());
    }

    if (whatsappBtn) {
      whatsappBtn.addEventListener("click", () => {
        const message = encodeURIComponent(
          "Bonjour, je souhaite obtenir des informations sur vos parfums."
        );
        window.open(`https://wa.me/33142869900?text=${message}`, "_blank");
        this.hidePopup();
      });
    }
  }
}

// Initialisation globale
const cartManager = new CartManager();
const adminManager = new AdminManager();
const popupManager = new PopupManager();

// Liaison des événements
function bindAddToCartEvents() {
  document.querySelectorAll(".btn-add-cart").forEach((button) => {
    button.addEventListener("click", function () {
      const product = this.getAttribute("data-product");
      const price = this.getAttribute("data-price");
      const image = this.getAttribute("data-image");
      cartManager.addToCart(product, price, image);
    });
  });
}

// Gestion des événements globaux
document.addEventListener("DOMContentLoaded", function () {
  // Initialiser le carrousel
  initCarousel();

  // Rendre les produits
  renderProducts();

  // Boutons de navigation hero
  const discoverBtn = document.getElementById("discoverBtn");
  const creationsBtn = document.getElementById("creationsBtn");

  if (discoverBtn) {
    discoverBtn.addEventListener("click", function () {
      document.querySelector(".products").scrollIntoView({
        behavior: "smooth"
      });
    });
  }

  if (creationsBtn) {
    creationsBtn.addEventListener("click", function () {
      document.querySelector(".custom-perfume").scrollIntoView({
        behavior: "smooth"
      });
    });
  }

  // Gestion du panier
  const cartIcon = document.getElementById("cartIcon");
  if (cartIcon) {
    cartIcon.addEventListener("click", function () {
      document.getElementById("miniCart").classList.toggle("show");
    });
  }

  // Validation WhatsApp
  const checkoutBtn = document.getElementById("checkoutBtn");
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", function () {
      if (cartManager.cart.length === 0) {
        alert("Votre panier est vide");
        return;
      }

      const message = cartManager.generateWhatsAppMessage();
      const url = `https://wa.me/33142869900?text=${message}`;
      window.open(url, "_blank");
    });
  }

  // Gestion du compte utilisateur
  const userAccount = document.getElementById("userAccount");
  const modalClose = document.getElementById("modalClose");

  if (userAccount) {
    userAccount.addEventListener("click", function () {
      document.getElementById("accountModal").classList.add("show");
    });
  }

  if (modalClose) {
    modalClose.addEventListener("click", function () {
      document.getElementById("accountModal").classList.remove("show");
    });
  }

  // Tabs du modal
  document.querySelectorAll(".modal-tab").forEach((tab) => {
    tab.addEventListener("click", function () {
      const tabName = this.getAttribute("data-tab");

      // Mettre à jour les tabs
      document
        .querySelectorAll(".modal-tab")
        .forEach((t) => t.classList.remove("active"));
      this.classList.add("active");

      // Mettre à jour le contenu
      document.querySelectorAll(".tab-content").forEach((content) => {
        content.classList.remove("active");
      });
      document.getElementById(tabName + "Tab").classList.add("active");
    });
  });

  // Forms
  const loginForm = document.getElementById("loginForm");
  const registerForm = document.getElementById("registerForm");
  const customPerfumeForm = document.getElementById("customPerfumeForm");

  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault();
      alert("Connexion réussie !");
      document.getElementById("accountModal").classList.remove("show");
    });
  }

  if (registerForm) {
    registerForm.addEventListener("submit", function (e) {
      e.preventDefault();
      alert("Inscription réussie ! Un email de confirmation a été envoyé.");
      document.getElementById("accountModal").classList.remove("show");
    });
  }

  if (customPerfumeForm) {
    customPerfumeForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const submitBtn = this.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;

      submitBtn.innerHTML = '<div class="loading"></div>';
      submitBtn.disabled = true;

      setTimeout(() => {
        submitBtn.textContent = "DEMANDE ENVOYÉE !";
        alert(
          "Merci pour votre demande de parfum personnalisé ! Notre maître parfumeur vous contactera dans les 48h."
        );
        this.reset();

        setTimeout(() => {
          submitBtn.textContent = originalText;
          submitBtn.disabled = false;
        }, 3000);
      }, 2000);
    });
  }

  // Fermer le mini-cart en cliquant à l'extérieur
  document.addEventListener("click", function (event) {
    const miniCart = document.getElementById("miniCart");
    const cartIcon = document.getElementById("cartIcon");

    if (
      miniCart &&
      miniCart.classList.contains("show") &&
      !miniCart.contains(event.target) &&
      !cartIcon.contains(event.target)
    ) {
      miniCart.classList.remove("show");
    }
  });

  // Animation au scroll
  function handleScrollAnimations() {
    const elements = document.querySelectorAll(".fade-in");
    elements.forEach((element) => {
      const elementTop = element.getBoundingClientRect().top;
      const windowHeight = window.innerHeight;

      if (elementTop < windowHeight - 100) {
        element.style.opacity = "1";
        element.style.transform = "translateY(0)";
      }
    });
  }

  // Initialiser les animations
  document.querySelectorAll(".fade-in").forEach((element) => {
    element.style.opacity = "0";
    element.style.transform = "translateY(30px)";
    element.style.transition = "opacity 0.6s ease, transform 0.6s ease";
  });

  window.addEventListener("scroll", handleScrollAnimations);
  handleScrollAnimations(); // Vérifier au chargement

  // Gestion responsive du menu mobile
  const mobileMenuBtn = document.querySelector(".mobile-menu-btn");
  if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener("click", function () {
      const navLinks = document.querySelector(".nav-links");
      const navIcons = document.querySelector(".nav-icons");

      if (navLinks.style.display === "flex") {
        navLinks.style.display = "none";
        navIcons.style.display = "none";
      } else {
        navLinks.style.display = "flex";
        navIcons.style.display = "flex";

        // Style pour mobile
        if (window.innerWidth <= 768) {
          navLinks.style.flexDirection = "column";
          navLinks.style.position = "absolute";
          navLinks.style.top = "100%";
          navLinks.style.left = "0";
          navLinks.style.right = "0";
          navLinks.style.background = "white";
          navLinks.style.padding = "20px";
          navLinks.style.boxShadow = "0 5px 15px rgba(0,0,0,0.1)";

          navIcons.style.flexDirection = "column";
          navIcons.style.position = "absolute";
          navIcons.style.top = "calc(100% + 200px)";
          navIcons.style.left = "0";
          navIcons.style.right = "0";
          navIcons.style.background = "white";
          navIcons.style.padding = "20px";
          navIcons.style.boxShadow = "0 5px 15px rgba(0,0,0,0.1)";
        }
      }
    });
  }
});

// Activation manuelle du mode admin (pour test)
function enableAdminMode() {
  localStorage.setItem("ambrosca-admin", "true");
  location.reload();
}

// Désactivation du mode admin
function disableAdminMode() {
  localStorage.setItem("ambrosca-admin", "false");
  location.reload();
}
